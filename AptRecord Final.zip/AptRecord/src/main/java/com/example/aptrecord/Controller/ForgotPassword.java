package com.example.aptrecord.Controller;

import com.example.aptrecord.Database.DBConnection;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ForgotPassword {
    @FXML private TextField emailField; // Email field input
    @FXML private PasswordField oldPasswordField; // Old password input
    @FXML private PasswordField newPasswordField; // New password input
    @FXML private PasswordField confirmPasswordField; // Confirm new password input
    @FXML private Text statusMessage; // For displaying error/success messages

    // Database connection instance
    private final Connection connection = DBConnection.getConnection(); // Assumes you have a method to get the connection

    public ForgotPassword() throws SQLException {}

    public void handleChangepassword(ActionEvent actionEvent) {
        String email = emailField.getText().trim();
        String oldPassword = oldPasswordField.getText().trim();
        String newPassword = newPasswordField.getText().trim();
        String confirmPassword = confirmPasswordField.getText().trim();

        // Step 1: Validate that all fields are filled in
        if (email.isEmpty() || oldPassword.isEmpty() || newPassword.isEmpty() || confirmPassword.isEmpty()) {
            statusMessage.setText("Please fill in all fields.");
            return;
        }

        // Step 2: Check if the new password and confirm password match
        if (!newPassword.equals(confirmPassword)) {
            statusMessage.setText("New passwords do not match.");
            return;
        }

        // Step 3: Validate email and old password with the database
        try {
            if (validateUserCredentials(email, oldPassword)) {
                // Step 4: Check if the old password has at least 2 matching characters with the new password
                if (hasMatchingCharacters(oldPassword, newPassword)) {
                    // Step 5: Update the password in the database
                    updatePassword(email, newPassword);
                    statusMessage.setText("Password changed successfully.");
                } else {
                    statusMessage.setText("Old and new passwords must share at least 2 matching characters.");
                }
            } else {
                statusMessage.setText("Incorrect email or old password.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            statusMessage.setText("Error occurred: " + e.getMessage());
        }
    }

    // Method to check if the old password and new password share at least 2 matching characters
    private boolean hasMatchingCharacters(String oldPassword, String newPassword) {
        int matchCount = 0;

        for (int i = 0; i < oldPassword.length(); i++) {
            for (int j = 0; j < newPassword.length(); j++) {
                if (oldPassword.charAt(i) == newPassword.charAt(j)) {
                    matchCount++;
                    if (matchCount >= 2) {
                        return true; // Return true as soon as we find 2 matching characters
                    }
                }
            }
        }

        return matchCount >= 2;
    }

    private boolean validateUserCredentials(String email, String oldPassword) throws SQLException {
        String query = "SELECT * FROM users WHERE email = ? AND password = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, email);
            stmt.setString(2, oldPassword);
            ResultSet resultSet = stmt.executeQuery();
            // Return true if the user exists with the given email and password
            return resultSet.next();
        }
    }

    private void updatePassword(String email, String newPassword) throws SQLException {
        String query = "UPDATE users SET password = ? WHERE email = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, newPassword);
            stmt.setString(2, email);
            int rowsUpdated = stmt.executeUpdate();
            // Check if the password was updated
            if (rowsUpdated == 0) {
                statusMessage.setText("Failed to update password.");
            }
        }
    }


    public void redirectToLogin(ActionEvent actionEvent) {
        try {
            // Load the Forgot Password page
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/com/example/aptrecord/LoginPage.fxml"));
            Parent root = fxmlLoader.load();

            // Create and show the new stage for Forgot Password page
            Stage stage = new Stage();
            stage.setTitle("Login");
            stage.setScene(new Scene(root));
            stage.show();

            // Get the current stage and close it
            Stage currentStage = (Stage) emailField.getScene().getWindow(); // Directly cast to Stage
            currentStage.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}