package com.example.aptrecord.models;

public class Electricity {
}
