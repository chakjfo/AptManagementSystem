package com.example.aptrecord.Controller;

import javafx.beans.property.*;

public class BillReceipt {
    private int receiptId;
    private String name;
    private String month;
    private String paymentDate;
    private double kwph;
    private double amount;
    private double amountPaid;
    private String timePaid;
    private String status;
    private String paymentMethod;
    private String accountNumber;
    private double balance;

    public BillReceipt(int receiptId, String name, String month, String paymentDate, double kwph, double amount,
                       double amountPaid, String timePaid, String status, String paymentMethod,
                       String accountNumber, double balance) {
        this.receiptId = receiptId;
        this.name = name;
        this.month = month;
        this.paymentDate = paymentDate;
        this.kwph = kwph;
        this.amount = amount;
        this.amountPaid = amountPaid;
        this.timePaid = timePaid;
        this.status = status;
        this.paymentMethod = paymentMethod;
        this.accountNumber = accountNumber;
        this.balance = balance;
    }

    // Getters for each field
    public int getReceiptId() {
        return receiptId;
    }

    public String getName() {
        return name;
    }

    public String getMonth() {
        return month;
    }

    public String getPaymentDate() {
        return paymentDate;
    }

    public double getKwph() {
        return kwph;
    }

    public double getAmount() {
        return amount;
    }

    public double getAmountPaid() {
        return amountPaid;
    }

    public String getTimePaid() {
        return timePaid;
    }

    public String getStatus() {
        return status;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public double getBalance() {
        return balance;
    }
}
