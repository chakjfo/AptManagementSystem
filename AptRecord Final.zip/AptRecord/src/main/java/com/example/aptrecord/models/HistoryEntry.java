package com.example.aptrecord.models;

import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;

import java.time.LocalDateTime;

public class HistoryEntry {
    private final SimpleStringProperty id;
    private final SimpleStringProperty info;
    private final SimpleObjectProperty<LocalDateTime> dateTime;

    public HistoryEntry(String id, String info, LocalDateTime dateTime) {
        this.id = new SimpleStringProperty(id);
        this.info = new SimpleStringProperty(info);
        this.dateTime = new SimpleObjectProperty<>(dateTime);
    }

    public String getId() {
        return id.get();
    }

    public String getInfo() {
        return info.get();
    }

    public LocalDateTime getDateTime() {
        return dateTime.get();
    }
}
