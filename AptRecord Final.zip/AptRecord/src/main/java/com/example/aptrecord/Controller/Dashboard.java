package com.example.aptrecord.Controller;

import com.example.aptrecord.models.HistoryEntry;
import javafx.animation.PauseTransition;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.*;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;
import com.example.aptrecord.Database.DBConnection;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import javafx.util.Duration;
import javafx.util.StringConverter;

import javax.swing.*;
import java.io.IOException;
import java.sql.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class Dashboard {
    public Button paywater, payelectricity;
    public TableColumn historyIdColumn, historyDateTimeColumn, historyInfoColumn;
    public TableView historyTableView;
    public Hyperlink viewallhrlnk;
    public TextField useridelectricity, electricityid, landlordelectrictyid, updatedelectricitykwph, updatedelectricityamount,
            useridwater, waterid, landlordwaterid, updatedwaterkwph, updatedwateramount;
    public TextField landlordIdField;
    public TableView databasetable;

    @FXML private TableView<BillReceipt> billReceiptTableView; // Match the FXML fx:id="billReceiptTableView"
    @FXML private TableColumn<BillReceipt, Integer> receipt_id;
    @FXML private TableColumn<BillReceipt, String> name;
    @FXML private TableColumn<BillReceipt, Date> month;
    @FXML private TableColumn<BillReceipt, Date> payment_date;
    @FXML private TableColumn<BillReceipt, Double> kwph;
    @FXML private TableColumn<BillReceipt, Double> amount;
    @FXML private TableColumn<BillReceipt, Double> amount_paid;
    @FXML private TableColumn<BillReceipt, Timestamp> time_paid;
    @FXML private TableColumn<BillReceipt, String> status;
    @FXML private TableColumn<BillReceipt, Integer> user_id;
    @FXML private TableColumn<BillReceipt, String> payment_method;
    @FXML private TableColumn<BillReceipt, String> account_number;
    @FXML private TableColumn<BillReceipt, Double> balance;
    @FXML private TableColumn<BillReceipt, String> utilityType;
    @FXML
    private DatePicker monthDatepicker;
    @FXML
    private ComboBox<Integer> userIdComboBox;
    @FXML
    private TabPane tabPane; // TabPane from FXML
    @FXML
    private RadioButton waterRadio, electricityRadio;
    @FXML
    private Tab settingtab, paytab, dashboardtab, historytab, admintab, contactustab, aboutustab;  // Setting Tab
    public Button settingbtn, paybtn, homebtn, savechanges, historybtn, logout, adminbtn,
            logout1,logout2, logout3, logout4, logout5, logout6, submitButton, aboutusbtn, contactusbtn;
    public Label roomnumber, totalpayment, waterpayment, firstname, electricitypayment;
    @FXML
    private LineChart<String, Number> waterchart, electricitychart;
    @FXML
    private TextField firstname1, lastname, email, roomnum, aptrequired,
            contactnum, waterkwph, wateramount, waterpay, watername,
            electricitykwph, electricitypay, electricityamount, kwphField,
            amountField,  electricityname;
    @FXML
    private DatePicker watermonth, waterdate, electricitymonth, electricitydate, monthField;
    private int userId; // User ID for database operations

    // Original field values for change tracking
    private String originalFirstName;
    private String originalLastName;
    private String originalEmail;
    private String originalRoomNumber;
    private String originalAptDateAcquired;
    private String originalContactNumber;
    private ToggleGroup toggleGroup;

    // Updated to accept both firstName and userId
    public void setFirstName(String firstName, int userId) {
        this.userId = userId; // Set user ID
        firstname.setText(firstName); // Set first name on the label
        loadWaterData(); // Load water data for the user
        loadElectricityData(); // Load electricity data for the user
        loadRoomNumber();
    }

    public void initializeUserData(int userId, String roomNumber) {
        this.userId = userId;
        roomnumber.setText(roomNumber);
        // Assign button actions
        paywater.setOnAction(event -> handleWaterPayment());
        payelectricity.setOnAction(event -> handleElectricityPayment());

        paybtn.setOnAction(this::handlePaybtn);
        settingbtn.setOnAction(this::handleSettingbtn);
        homebtn.setOnAction(this::handleHomebtn);
        savechanges.setOnAction(this::handleSaveChanges);
        contactusbtn.setOnAction(this::handleContactusbtn);
        aboutusbtn.setOnAction(this::handleAboutusbtn);
        paybtn.setOnAction(this::handlePaybtn);
        logout.setOnAction(this::handleLogout);
        logout1.setOnAction(this::handleLogout);
        logout2.setOnAction(this::handleLogout);
        logout3.setOnAction(this::handleLogout);
        logout4.setOnAction(this::handleLogout);
        logout5.setOnAction(this::handleLogout);
        logout6.setOnAction(this::handleLogout);
        loadUserData();
        historybtn.setOnAction(this::handleHistorybtn);
    }

    @FXML
    private void handleAboutusbtn(ActionEvent actionEvent) {
        tabPane.getSelectionModel().select(aboutustab);
    }

    @FXML
    private void handleContactusbtn(ActionEvent actionEvent) {
        tabPane.getSelectionModel().select(contactustab);
    }

    public void initialize() {
        populateUserIdDropdown(); // Call this during initialization
        billReceiptTableView.setEditable(true); // Initialize the columns
        setupTableColumns(); // Load the initial data
        loadBillData(); // Enable sorting
        // Add a key event listener to detect backspace key press
        billReceiptTableView.addEventHandler(KeyEvent.KEY_PRESSED, new EventHandler<KeyEvent>() {
            @Override
            public void handle(KeyEvent event) {
                // Check if the backspace key is pressed
                if (event.getCode() == KeyCode.BACK_SPACE) {
                    BillReceipt selectedBill = billReceiptTableView.getSelectionModel().getSelectedItem();

                    // If a row is selected, prompt for confirmation
                    if (selectedBill != null) {
                        showDeleteConfirmationDialog(selectedBill);
                    }
                }
            }
        });
        billReceiptTableView.getSortOrder().clear();
        setupPaymentTextField(electricitypay);
        setupPaymentTextField(waterpay);  // If you want the same behavior for water payments
    }

    @FXML
    private void handleLogout(ActionEvent actionEvent) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/aptrecord/LoginPage.fxml"));
            Parent root = loader.load();

            Stage stage = (Stage) roomnumber.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Login Page");
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showInputDialog("Error loading the Login page. Please try again.");
        }
    }

    @FXML
    private void handleHistorybtn(ActionEvent actionEvent) {
        tabPane.getSelectionModel().select(historytab);
        loadHistoryData();
    }

    @FXML
    private void handleAdminbtn(ActionEvent actionEvent) {
        // Prompt for admin password
        TextInputDialog passwordDialog = new TextInputDialog();
        passwordDialog.setTitle("Admin Login");
        passwordDialog.setHeaderText("Enter Admin Password");
        passwordDialog.setContentText("Password:");

        // Show the dialog and wait for user input
        Optional<String> result = passwordDialog.showAndWait();

        // Check if the password is correct
        if (result.isPresent()) {
            String enteredPassword = result.get();

            // Define the correct password (you can change this to any password)
            String correctPassword = "admin123";  // Example password

            if (correctPassword.equals(enteredPassword)) {
                // If the password is correct, select the admin tab
                tabPane.getSelectionModel().select(admintab);
                loadBillData();


            } else {
                // If the password is incorrect, show an error message
                showErrorAlert("Access Denied", "Incorrect admin password.");
            }
        }
    }

    public class BillReceipt {
        private Integer receiptId;
        private String name;
        private Date month;
        private Date paymentDate;
        private Double kwph;
        private Double amount;
        private Double amountPaid;
        private Timestamp timePaid;
        private String status;
        private Integer userId;
        private String paymentMethod;
        private String accountNumber;
        private Double balance;
        private String utilityType; // to distinguish between water and electricity

        // Constructor
        public BillReceipt(Integer receiptId, String name, Date month, Date paymentDate,
                           Double kwph, Double amount, Double amountPaid, Timestamp timePaid,
                           String status, Integer userId, String paymentMethod,
                           String accountNumber, Double balance, String utilityType) {
            this.receiptId = receiptId;
            this.name = name;
            this.month = month;
            this.paymentDate = paymentDate;
            this.kwph = kwph;
            this.amount = amount;
            this.amountPaid = amountPaid;
            this.timePaid = timePaid;
            this.status = status;
            this.userId = userId;
            this.paymentMethod = paymentMethod;
            this.accountNumber = accountNumber;
            this.balance = balance;
            this.utilityType = utilityType;
        }

        // Getters
        public Integer getReceiptId() { return receiptId; }
        public String getName() { return name; }
        public Date getMonth() { return month; }
        public Date getPaymentDate() { return paymentDate; }
        public Double getKwph() { return kwph; }
        public Double getAmount() { return amount; }
        public Double getAmountPaid() { return amountPaid; }
        public Timestamp getTimePaid() { return timePaid; }
        public String getStatus() { return status; }
        public Integer getUserId() { return userId; }
        public String getPaymentMethod() { return paymentMethod; }
        public String getAccountNumber() { return accountNumber; }
        public Double getBalance() { return balance; }
        public String getUtilityType() { return utilityType; }

        // Add setters
        public void setName(String name) { this.name = name; }
        public void setMonth(Date month) { this.month = month; }
        public void setPaymentDate(Date paymentDate) { this.paymentDate = paymentDate; }
        public void setKwph(Double kwph) { this.kwph = kwph; }
        public void setAmount(Double amount) { this.amount = amount; }
        public void setAmountPaid(Double amountPaid) { this.amountPaid = amountPaid; }
        public void setTimePaid(Timestamp timePaid) { this.timePaid = timePaid; }
        public void setStatus(String status) { this.status = status; }
        public void setUserId(Integer userId) { this.userId = userId; }
        public void setPaymentMethod(String paymentMethod) { this.paymentMethod = paymentMethod; }
        public void setAccountNumber(String accountNumber) { this.accountNumber = accountNumber; }
        public void setBalance(Double balance) { this.balance = balance; }
    }

    private void setupTableColumns() {
        receipt_id.setCellValueFactory(new PropertyValueFactory<>("receiptId"));
        name.setCellValueFactory(new PropertyValueFactory<>("name"));
        month.setCellValueFactory(new PropertyValueFactory<>("month"));
        payment_date.setCellValueFactory(new PropertyValueFactory<>("paymentDate"));
        kwph.setCellValueFactory(new PropertyValueFactory<>("kwph"));
        amount.setCellValueFactory(new PropertyValueFactory<>("amount"));
        amount_paid.setCellValueFactory(new PropertyValueFactory<>("amountPaid"));
        time_paid.setCellValueFactory(new PropertyValueFactory<>("timePaid"));
        status.setCellValueFactory(new PropertyValueFactory<>("status"));
        user_id.setCellValueFactory(new PropertyValueFactory<>("userId"));
        payment_method.setCellValueFactory(new PropertyValueFactory<>("paymentMethod"));
        account_number.setCellValueFactory(new PropertyValueFactory<>("accountNumber"));
        balance.setCellValueFactory(new PropertyValueFactory<>("balance"));
        utilityType.setCellValueFactory(new PropertyValueFactory<>("utilityType"));

        // Make table editable with Enter key support
        billReceiptTableView.setEditable(true);

        // Name column
        name.setCellFactory(col -> {
            TextFieldTableCell<BillReceipt, String> cell = new TextFieldTableCell<>(TextFormatter.IDENTITY_STRING_CONVERTER);
            setupEnterKeyHandler(cell);
            return cell;
        });
        name.setOnEditCommit(event -> {
            BillReceipt bill = event.getRowValue();
            bill.setName(event.getNewValue());
            updateDatabase(bill);
        });

        // Amount columns
        StringConverter<Double> doubleConverter = new StringConverter<Double>() {
            @Override
            public String toString(Double object) {
                return object == null ? "0.0" : object.toString();
            }

            @Override
            public Double fromString(String string) {
                try {
                    return string.isEmpty() ? 0.0 : Double.parseDouble(string);
                } catch (NumberFormatException e) {
                    return 0.0;
                }
            }
        };

        amount.setCellFactory(col -> {
            TextFieldTableCell<BillReceipt, Double> cell = new TextFieldTableCell<>(doubleConverter);
            setupEnterKeyHandler(cell);
            return cell;
        });
        amount.setOnEditCommit(event -> {
            BillReceipt bill = event.getRowValue();
            bill.setAmount(event.getNewValue());
            updateDatabase(bill);
        });

        // Similar pattern for other editable columns
        amount_paid.setCellFactory(col -> {
            TextFieldTableCell<BillReceipt, Double> cell = new TextFieldTableCell<>(doubleConverter);
            setupEnterKeyHandler(cell);
            return cell;
        });
        amount_paid.setOnEditCommit(event -> {
            BillReceipt bill = event.getRowValue();
            bill.setAmountPaid(event.getNewValue());
            updateDatabase(bill);
        });

        // Date converter
        StringConverter<Date> dateConverter = new StringConverter<Date>() {
            private final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

            @Override
            public String toString(Date object) {
                return object == null ? "" : dateFormat.format(object);
            }

            @Override
            public java.sql.Date fromString(String string) {
                try {
                    return string.isEmpty() ? null : new java.sql.Date(dateFormat.parse(string).getTime());
                } catch (ParseException e) {
                    return null;
                }
            }
        };

        payment_date.setCellFactory(col -> {
            TextFieldTableCell<BillReceipt, Date> cell = new TextFieldTableCell<>(dateConverter);
            setupEnterKeyHandler(cell);
            return cell;
        });
        payment_date.setOnEditCommit(event -> {
            BillReceipt bill = event.getRowValue();
            bill.setPaymentDate(event.getNewValue());
            updateDatabase(bill);
        });

        // Status column
        status.setCellFactory(col -> {
            TextFieldTableCell<BillReceipt, String> cell = new TextFieldTableCell<>(TextFormatter.IDENTITY_STRING_CONVERTER);
            setupEnterKeyHandler(cell);
            return cell;
        });
        status.setOnEditCommit(event -> {
            BillReceipt bill = event.getRowValue();
            bill.setStatus(event.getNewValue());
            updateDatabase(bill);
        });

        // Payment method column
        payment_method.setCellFactory(col -> {
            TextFieldTableCell<BillReceipt, String> cell = new TextFieldTableCell<>(TextFormatter.IDENTITY_STRING_CONVERTER);
            setupEnterKeyHandler(cell);
            return cell;
        });
        payment_method.setOnEditCommit(event -> {
            BillReceipt bill = event.getRowValue();
            bill.setPaymentMethod(event.getNewValue());
            updateDatabase(bill);
        });
    }

    // Helper method to setup Enter key handler
    private <T> void setupEnterKeyHandler(TextFieldTableCell<BillReceipt, T> cell) {
        cell.setOnKeyPressed(event -> {
            if (event.getCode() == KeyCode.ENTER) {
                cell.commitEdit(cell.getConverter().fromString(cell.getText()));
            }
        });
    }
    private void showDeleteConfirmationDialog(BillReceipt selectedBill) {
        // Create a confirmation dialog
        Alert confirmationDialog = new Alert(AlertType.CONFIRMATION);
        confirmationDialog.setTitle("Delete Confirmation");
        confirmationDialog.setHeaderText("Are you sure you want to delete this bill?");
        confirmationDialog.setContentText("This action cannot be undone.");

        // Show the dialog and wait for the user's response
        confirmationDialog.showAndWait().ifPresent(response -> {
            if (response == ButtonType.OK) {
                // User confirmed, delete the row from both the table and the database
                deleteBillReceipt(selectedBill);
            }
        });
    }

    private void deleteBillReceipt(BillReceipt selectedBill) {
        String tableName = selectedBill.getUtilityType().toLowerCase();  // Use 'water' or 'electricity'

        String query = "DELETE FROM " + tableName + " WHERE receipt_id = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setInt(1, selectedBill.getReceiptId());

            // Execute the delete query
            int rowsAffected = pstmt.executeUpdate();

            if (rowsAffected > 0) {
                // If the deletion is successful, remove the item from the table view
                billReceiptTableView.getItems().remove(selectedBill);
                showSuccessAlert("Deletion Successful", "Bill receipt deleted successfully!");
            } else {
                showErrorAlert("Deletion Failed", "No records were deleted.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
            showErrorAlert("Database Error", "Error deleting record: " + e.getMessage());
        }
    }

    private void updateDatabase(BillReceipt bill) {
        String tableName = bill.getUtilityType().toLowerCase();
        String query = "UPDATE " + tableName + " SET " +
                "name = ?, " +
                "payment_date = ?, " +
                "amount = ?, " +
                "amount_paid = ?, " +
                "status = ?, " +
                "payment_method = ? " +
                "WHERE receipt_id = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setString(1, bill.getName());

            // Handle null payment date
            if (bill.getPaymentDate() != null) {
                pstmt.setDate(2, new java.sql.Date(bill.getPaymentDate().getTime()));
            } else {
                pstmt.setNull(2, java.sql.Types.DATE);
            }

            pstmt.setDouble(3, bill.getAmount() != null ? bill.getAmount() : 0.0);
            pstmt.setDouble(4, bill.getAmountPaid() != null ? bill.getAmountPaid() : 0.0);
            pstmt.setString(5, bill.getStatus());
            pstmt.setString(6, bill.getPaymentMethod());
            pstmt.setInt(7, bill.getReceiptId());

            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected > 0) {
                showSuccessAlert("Update Successful", "Record updated successfully!");
            } else {
                showErrorAlert("Update Failed", "No records were updated.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
            showErrorAlert("Database Error", "Error updating record: " + e.getMessage());
        }
    }

    private void loadBillData() {
        ObservableList<BillReceipt> billReceipts = FXCollections.observableArrayList();

        try (Connection conn = DBConnection.getConnection()) {
            if (conn == null) {
                System.out.println("Database connection failed!");
                return;
            }

            // Load water bills
            String waterQuery = "SELECT receipt_id, name, month, payment_date, kwph, amount, " +
                    "amount_paid, time_paid, status, user_id, payment_method, account_number, " +
                    "balance FROM water";

            try (PreparedStatement waterStmt = conn.prepareStatement(waterQuery);
                 ResultSet waterRs = waterStmt.executeQuery()) {

                while (waterRs.next()) {
                    billReceipts.add(createBillReceiptFromResultSet(waterRs, "Water"));
                }
            }

            // Load electricity bills
            String electricityQuery = "SELECT receipt_id, name, month, payment_date, kwph, amount, " +
                    "amount_paid, time_paid, status, user_id, payment_method, account_number, " +
                    "balance FROM electricity";

            try (PreparedStatement electricityStmt = conn.prepareStatement(electricityQuery);
                 ResultSet electricityRs = electricityStmt.executeQuery()) {

                while (electricityRs.next()) {
                    billReceipts.add(createBillReceiptFromResultSet(electricityRs, "Electricity"));
                }
            }

            // Set items to table
            Platform.runLater(() -> {
                billReceiptTableView.setItems(billReceipts);
                System.out.println("Loaded " + billReceipts.size() + " bills");
            });

        } catch (SQLException e) {
            e.printStackTrace();
            showErrorAlert("Database Error", "Error loading bill data: " + e.getMessage());
        }
    }

    private BillReceipt createBillReceiptFromResultSet(ResultSet rs, String utilityType) throws SQLException {
        return new BillReceipt(
                rs.getInt("receipt_id"),
                rs.getString("name"),
                rs.getDate("month"),
                rs.getDate("payment_date"),
                rs.getDouble("kwph"),
                rs.getDouble("amount"),
                rs.getDouble("amount_paid"),
                rs.getTimestamp("time_paid"),
                rs.getString("status"),
                rs.getInt("user_id"),
                rs.getString("payment_method"),
                rs.getString("account_number"),
                rs.getDouble("balance"),
                utilityType
        );
    }

    @FXML
    private void refreshTable() {
        billReceiptTableView.getItems().clear();
        loadBillData();
    }

    @FXML
    private void handleHomebtn(ActionEvent event) {
        // Select the "Settings" tab
        tabPane.getSelectionModel().select(dashboardtab);

    }

    @FXML
    private void handleSettingbtn(ActionEvent event) {
        // Select the "Settings" tab
        tabPane.getSelectionModel().select(settingtab);

        // Load the user data
        loadUserData();

        // Populate the firstname TextField on the Settings tab
        firstname1.setText(firstname.getText());

        // Validate the inputs
        validateInputs();

        // Get the changed fields
        String changedFields = getChangedFields();

        // Save the changes if any
        if (!changedFields.isEmpty()) {
            saveChanges();
            getChangedFields();

            // Update the firstname field on the Dashboard tab
            firstname.setText(firstname1.getText());
        } else {
            System.out.println("No changes detected to save.");
        }
    }

    public void handleViewall(ActionEvent actionEvent) {
        tabPane.getSelectionModel().select(3);
    }

    @FXML
    private void handlePaybtn(ActionEvent event) {
        // Select the "Pay" tab
        tabPane.getSelectionModel().select(paytab);

        // Add listeners to date pickers to fetch and display details when a month is selected
        watermonth.setOnAction(e -> updateWaterDetails());
        electricitymonth.setOnAction(e -> updateElectricityDetails());

    }

    private void loadWaterData() {
        String chartQuery = "SELECT MONTH(month) AS month, SUM(amount) AS total_amount " +
                "FROM water WHERE user_id = ? GROUP BY MONTH(month)";
        String sumQuery = "SELECT SUM(amount) AS total_payment FROM water WHERE user_id = ?";

        try (Connection conn = DBConnection.getConnection()) {
            // Execute chart query (existing functionality)
            try (PreparedStatement chartStmt = conn.prepareStatement(chartQuery)) {
                chartStmt.setInt(1, userId);
                try (ResultSet rs = chartStmt.executeQuery()) {
                    XYChart.Series<String, Number> series = new XYChart.Series<>();
                    series.setName("Water Usage");

                    while (rs.next()) {
                        int monthNumber = rs.getInt("month");
                        double totalAmount = rs.getDouble("total_amount");
                        String monthName = convertMonthToWord(monthNumber);
                        series.getData().add(new XYChart.Data<>(monthName, totalAmount));
                    }
                    waterchart.getData().add(series);
                }
            }

            try (PreparedStatement sumStmt = conn.prepareStatement(sumQuery)) {
                sumStmt.setInt(1, userId);
                try (ResultSet sumRs = sumStmt.executeQuery()) {
                    if (sumRs.next()) {
                        double totalPayment = sumRs.getDouble("total_payment");
                        waterpayment.setText(String.format("₱%.2f", totalPayment)); // Display total amount in the label
                    }
                }
            }

            // Update total payment (water payment is now updated)
            updateTotalPayment();

        } catch (SQLException e) {
            handleSQLException(e, "Unable to load water data or calculate total payment.");
        }
    }

    private void loadElectricityData() {
        String chartQuery = "SELECT MONTH(month) AS month, SUM(amount) AS total_amount " +
                "FROM electricity WHERE user_id = ? GROUP BY MONTH(month)";
        String sumQuery = "SELECT SUM(amount) AS total_payment FROM electricity WHERE user_id = ?";

        try (Connection conn = DBConnection.getConnection()) {
            try (PreparedStatement chartStmt = conn.prepareStatement(chartQuery)) {
                chartStmt.setInt(1, userId);
                try (ResultSet rs = chartStmt.executeQuery()) {
                    XYChart.Series<String, Number> series = new XYChart.Series<>();
                    series.setName("Electricity Usage");

                    while (rs.next()) {
                        int monthNumber = rs.getInt("month");
                        double totalAmount = rs.getDouble("total_amount");
                        String monthName = convertMonthToWord(monthNumber);
                        series.getData().add(new XYChart.Data<>(monthName, totalAmount));
                    }
                    electricitychart.getData().add(series);
                }
            }

            try (PreparedStatement sumStmt = conn.prepareStatement(sumQuery)) {
                sumStmt.setInt(1, userId);
                try (ResultSet sumRs = sumStmt.executeQuery()) {
                    if (sumRs.next()) {
                        double totalPayment = sumRs.getDouble("total_payment");
                        electricitypayment.setText(String.format("₱%.2f", totalPayment));
                    }
                }
            }

            // Update total payment (electricity payment is now updated)
            updateTotalPayment();

        } catch (SQLException e) {
            handleSQLException(e, "Unable to load electricity data or calculate total payment.");
        }
    }

    private double getWaterPayment() {
        try {
            String text = waterpayment.getText().replace("₱", "").trim();
            return Double.parseDouble(text);
        } catch (NumberFormatException e) {
            return 0.0;
        }
    }

    private double getElectricityPayment() {
        try {
            String text = electricitypayment.getText().replace("₱", "").trim();
            return Double.parseDouble(text);
        } catch (NumberFormatException e) {
            return 0.0;
        }
    }
    private void updateTotalPayment() {
        double totalWaterPayment = getWaterPayment();
        double totalElectricityPayment = getElectricityPayment();
        double total = totalWaterPayment + totalElectricityPayment;
        totalpayment.setText(String.format("₱%.2f", total));
    }


    private String convertMonthToWord(int monthNumber) {
        switch (monthNumber) {
            case 1:
                return "Jan";
            case 2:
                return "Feb";
            case 3:
                return "Mar";
            case 4:
                return "Apr";
            case 5:
                return "May";
            case 6:
                return "Jun";
            case 7:
                return "Jul";
            case 8:
                return "Aug";
            case 9:
                return "Sept";
            case 10:
                return "Oct";
            case 11:
                return "Nov";
            case 12:
                return "Dec";
            default:
                return "";
        }
    }

    private void loadRoomNumber() {
        String query = "SELECT room_number FROM user_account WHERE id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, userId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    String roomNumberValue = rs.getString("room_number");
                    roomnumber.setText(roomNumberValue); // Display room number in the dashboard
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Database Error");
            alert.setHeaderText("Unable to load room number.");
            alert.setContentText(e.getMessage());
            alert.showAndWait();
        }
    }

    private void handleSQLException(SQLException e, String customMessage) {
        System.out.println(customMessage);
        e.printStackTrace();
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Database Error");
        alert.setHeaderText("An error occurred while fetching data.");
        alert.setContentText(e.getMessage());
        alert.showAndWait();
    }

    // Method to retrieve user's first name from the database
    private String getUserFirstName(int userId) {
        String firstName = null;
        String query = "SELECT first_name FROM user_account WHERE id = ?";

        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setInt(1, userId);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    firstName = resultSet.getString("first_name");
                    System.out.println("First Name Found: " + firstName); // Debug print
                } else {
                    System.out.println("No first name found for userId: " + userId);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("SQL Error retrieving first name: " + e.getMessage());
        }

        return firstName;
    }

    private void loadUserData() {
        String query = "SELECT first_name, last_name, email, room_number, apt_date_acquired, contact_number "
                + "FROM user_account WHERE id = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, userId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    // Populate fields
                    firstname.setText(rs.getString("first_name"));
                    lastname.setText(rs.getString("last_name"));
                    email.setText(rs.getString("email"));
                    roomnum.setText(rs.getString("room_number"));
                    aptrequired.setText(rs.getString("apt_date_acquired"));
                    contactnum.setText(rs.getString("contact_number"));

                    // Store original values
                    originalFirstName = rs.getString("first_name");
                    originalLastName = rs.getString("last_name");
                    originalEmail = rs.getString("email");
                    originalRoomNumber = rs.getString("room_number");
                    originalAptDateAcquired = rs.getString("apt_date_acquired");
                    originalContactNumber = rs.getString("contact_number");
                } else {
                    showErrorAlert("No Data Found", "Unable to retrieve user information.");
                }
            }
        } catch (SQLException e) {
            showErrorAlert("Database Error", "Error loading user data: " + e.getMessage());
        }
    }


    private String getChangedFields() {
        StringBuilder changedFields = new StringBuilder();

        if (!firstname1.getText().equals(originalFirstName)) changedFields.append("First Name\n");
        if (!lastname.getText().equals(originalLastName)) changedFields.append("Last Name\n");
        if (!email.getText().equals(originalEmail)) changedFields.append("Email\n");
        if (!roomnum.getText().equals(originalRoomNumber)) changedFields.append("Room Number\n");
        if (!aptrequired.getText().equals(originalAptDateAcquired)) changedFields.append("Date Acquired\n");
        if (!contactnum.getText().equals(originalContactNumber)) changedFields.append("Contact Number\n");

        return changedFields.toString();
    }

    @FXML
    private void handleSaveChanges(ActionEvent event) {
        String changedFields = getChangedFields();

        if (!changedFields.isEmpty()) {
            Alert confirmationAlert = new Alert(AlertType.CONFIRMATION);
            confirmationAlert.setTitle("Confirm Changes");
            confirmationAlert.setHeaderText("You have made changes to the following fields:");
            confirmationAlert.setContentText(changedFields);

            confirmationAlert.showAndWait().ifPresent(response -> {
                if (response == ButtonType.OK) {
                    saveChanges();

                    // Update the firstname field on the Dashboard tab
                    firstname.setText(firstname1.getText());
                }
            });
        } else {
            showInformationAlert("No Changes", "No changes detected to save.");
        }
    }

    private void saveChanges() {
        String updateQuery = "UPDATE user_account SET first_name = ?, last_name = ?, email = ?, "
                + "room_number = ?, apt_date_acquired = ?, contact_number = ? WHERE id = ?";
        String insertHistoryQuery = "INSERT INTO history (user_id, id, info, date_time) VALUES (?, ?, ?, NOW())";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement updateStmt = conn.prepareStatement(updateQuery);
             PreparedStatement historyStmt = conn.prepareStatement(insertHistoryQuery)) {

            if (!validateInputs()) return;

            // Update the user_account table
            updateStmt.setString(1, firstname.getText().trim());
            updateStmt.setString(2, lastname.getText().trim());
            updateStmt.setString(3, email.getText().trim());
            updateStmt.setString(4, roomnum.getText().trim());
            updateStmt.setString(5, aptrequired.getText().trim());
            updateStmt.setString(6, contactnum.getText().trim());
            updateStmt.setInt(7, userId);

            int rowsAffected = updateStmt.executeUpdate();

            if (rowsAffected > 0) {
                StringBuilder changedFieldsInfo = new StringBuilder("Settings updated: ");

                // Generate a message for successfully updated fields
                if (!firstname.getText().equals(originalFirstName)) changedFieldsInfo.append("First Name, ");
                if (!lastname.getText().equals(originalLastName)) changedFieldsInfo.append("Last Name, ");
                if (!email.getText().equals(originalEmail)) changedFieldsInfo.append("Email, ");
                if (!roomnum.getText().equals(originalRoomNumber)) changedFieldsInfo.append("Room Number, ");
                if (!aptrequired.getText().equals(originalAptDateAcquired)) changedFieldsInfo.append("Date Acquired, ");
                if (!contactnum.getText().equals(originalContactNumber)) changedFieldsInfo.append("Contact Number, ");

                // Remove trailing comma and space if present
                String infoMessage = changedFieldsInfo.toString().trim();
                if (infoMessage.endsWith(",")) {
                    infoMessage = infoMessage.substring(0, infoMessage.length() - 1);
                }

                // Save changes into the history table
                historyStmt.setInt(1, userId);
                historyStmt.setString(2, "settings"); // Identifies this came from settings tab
                historyStmt.setString(3, infoMessage);
                historyStmt.executeUpdate();

                showSuccessAlert("Success", "User data updated successfully.");
                loadUserData();
            } else {
                showErrorAlert("Update Failed", "No rows were updated.");
            }
        } catch (SQLException e) {
            showErrorAlert("Database Error", "Error updating user data: " + e.getMessage());
        }
    }


    private boolean validateInputs() {
        if (firstname.getText().trim().isEmpty()) {
            showErrorAlert("Validation Error", "First Name cannot be empty.");
            return false;
        }
        if (lastname.getText().trim().isEmpty()) {
            showErrorAlert("Validation Error", "Last Name cannot be empty.");
            return false;
        }
        if (email.getText().trim().isEmpty() || !isValidEmail(email.getText().trim())) {
            showErrorAlert("Validation Error", "Please enter a valid email address.");
            return false;
        }
        if (contactnum.getText().trim().isEmpty()) {
            showErrorAlert("Validation Error", "Contact Number cannot be empty.");
            return false;
        }
        return true;
    }


    private boolean isValidEmail(String email) {
        String emailRegex = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$";
        return email.matches(emailRegex);
    }

    // Utility methods for showing alerts
    private void showSuccessAlert(String title, String message) {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(message);
        alert.show();

        PauseTransition pause = new PauseTransition(Duration.seconds(3));
        pause.setOnFinished(event -> alert.close());
        pause.play();
    }

    private void showErrorAlert(String title, String message) {
        Alert alert = new Alert(AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(message);
        alert.showAndWait();
    }

    private void showInformationAlert(String title, String message) {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(message);
        alert.showAndWait();
    }

    private void updateWaterDetails() {
        LocalDate selectedMonth = watermonth.getValue();
        if (selectedMonth != null) {
            // Extract the year and month from the selected date (yyyy-MM)
            String yearMonth = selectedMonth.getYear() + "-" + String.format("%02d", selectedMonth.getMonthValue());

            // Query to fetch water details for the specific user and the selected billing month
            String query = "SELECT amount, kwph FROM water WHERE user_id = ? AND DATE_FORMAT(month, '%Y-%m') = ?";

            try (Connection connection = DBConnection.getConnection();
                 PreparedStatement statement = connection.prepareStatement(query)) {

                statement.setInt(1, userId);  // Use the current user's ID
                statement.setString(2, yearMonth);  // Compare the selected year-month with the `month` field in the database

                ResultSet resultSet = statement.executeQuery();

                if (resultSet.next()) {
                    // Set the amount and kwph in the text fields
                    wateramount.setText(String.format("%.2f", resultSet.getDouble("amount")));
                    waterkwph.setText(String.format("%.2f", resultSet.getDouble("kwph")));
                } else {
                    // Clear fields if no data found
                    wateramount.setText("N/A");
                    waterkwph.setText("N/A");

                    // Optionally show an information dialog
                    showInformationAlert("No Data", "No water bill found for the selected month.");
                }

            } catch (SQLException e) {
                // Handle database errors
                showErrorAlert("Database Error", "Error retrieving water bill details: " + e.getMessage());
            }
        }
    }

    private void updateElectricityDetails() {
        LocalDate selectedMonth = electricitymonth.getValue();
        if (selectedMonth != null) {
            // Extract the year and month from the selected date (yyyy-MM)
            String yearMonth = selectedMonth.getYear() + "-" + String.format("%02d", selectedMonth.getMonthValue());

            // Query to fetch electricity details for the specific user and the selected billing month
            String query = "SELECT amount, kwph FROM electricity WHERE user_id = ? AND DATE_FORMAT(month, '%Y-%m') = ?";

            try (Connection connection = DBConnection.getConnection();
                 PreparedStatement statement = connection.prepareStatement(query)) {

                statement.setInt(1, userId);  // Use the current user's ID
                statement.setString(2, yearMonth);  // Compare the selected year-month with the `month` field in the database

                ResultSet resultSet = statement.executeQuery();

                if (resultSet.next()) {
                    // Set the amount and kwph in the text fields
                    electricityamount.setText(String.format("%.2f", resultSet.getDouble("amount")));
                    electricitykwph.setText(String.format("%.2f", resultSet.getDouble("kwph")));
                } else {
                    // Clear fields if no data found
                    electricityamount.setText("N/A");
                    electricitykwph.setText("N/A");

                    // Optionally show an information dialog
                    showInformationAlert("No Data", "No electricity bill found for the selected month.");
                }

            } catch (SQLException e) {
                // Handle database errors
                showErrorAlert("Database Error", "Error retrieving electricity bill details: " + e.getMessage());
            }
        }
    }

    @FXML
    private void handleElectricityPayment() {
        // Input validation first
        if (!validateElectricityPayment()) {
            return;
        }

        // Payment method selection dialog
        Dialog<String> paymentMethodDialog = new Dialog<>();
        paymentMethodDialog.setTitle("Select Payment Method");
        paymentMethodDialog.setHeaderText("Choose how you want to pay for electricity bill");

        ButtonType gcashButton = new ButtonType("GCash");
        ButtonType cardButton = new ButtonType("Credit/Debit Card");
        ButtonType cancelButton = new ButtonType("Cancel", ButtonBar.ButtonData.CANCEL_CLOSE);

        paymentMethodDialog.getDialogPane().getButtonTypes().addAll(gcashButton, cardButton, cancelButton);

        paymentMethodDialog.setResultConverter(dialogButton -> {
            if (dialogButton == gcashButton) {
                return "gcash";
            } else if (dialogButton == cardButton) {
                return "card";
            }
            return null;
        });

        paymentMethodDialog.showAndWait().ifPresent(paymentMethod -> {
            if (paymentMethod.equals("gcash")) {
                processGcashPayment("electricity");
            } else if (paymentMethod.equals("card")) {
                processCardPayment("electricity");
            }
        });
    }

    private boolean validateElectricityPayment() {
        try {
            // Check if month is selected
            if (electricitymonth.getValue() == null) {
                showErrorAlert("Invalid Input", "Please select a month for payment.");
                return false;
            }

            // Get the payment amount and bill amount
            String paymentText = electricitypay.getText().trim();
            String billAmountText = electricityamount.getText().trim();

            // Check if payment field is empty
            if (paymentText.isEmpty()) {
                showErrorAlert("Invalid Input", "Please enter a payment amount.");
                return false;
            }

            // Parse and validate payment amount
            double paymentAmount = Double.parseDouble(paymentText);
            double billAmount = Double.parseDouble(billAmountText);

            // Check for negative or zero payment
            if (paymentAmount <= 0) {
                showErrorAlert("Invalid Input", "Payment amount must be greater than zero.");
                return false;
            }

            // Optional: Check if payment amount is reasonable (e.g., not more than double the bill)
            if (paymentAmount > billAmount * 2) {
                boolean proceed = showConfirmationDialog("Confirm Payment",
                        "The payment amount is significantly higher than the bill amount. Do you want to proceed?");
                if (!proceed) {
                    return false;
                }
            }

            return true;

        } catch (NumberFormatException e) {
            showErrorAlert("Invalid Input", "Please enter a valid payment amount (numbers only).");
            return false;
        }
    }

    // Method to handle water bill payment
    @FXML
    private void handleWaterPayment() {
        // Payment method selection dialog
        Dialog<String> paymentMethodDialog = new Dialog<>();
        paymentMethodDialog.setTitle("Select Payment Method");
        paymentMethodDialog.setHeaderText("Choose how you want to pay for water bill");

        ButtonType gcashButton = new ButtonType("GCash");
        ButtonType cardButton = new ButtonType("Credit/Debit Card");
        ButtonType cancelButton = new ButtonType("Cancel", ButtonBar.ButtonData.CANCEL_CLOSE);

        paymentMethodDialog.getDialogPane().getButtonTypes().addAll(gcashButton, cardButton, cancelButton);

        paymentMethodDialog.setResultConverter(dialogButton -> {
            if (dialogButton == gcashButton) {
                return "gcash";
            } else if (dialogButton == cardButton) {
                return "card";
            }
            return null;
        });

        paymentMethodDialog.showAndWait().ifPresent(paymentMethod -> {
            if (paymentMethod.equals("gcash")) {
                processGcashPayment("water");
            } else if (paymentMethod.equals("card")) {
                processCardPayment("water");
            }
        });
    }

    private void processGcashPayment(String paymentType) {
        Dialog<String> gcashDialog = new Dialog<>();
        gcashDialog.setTitle("GCash Payment");
        gcashDialog.setHeaderText("Enter GCash Account Details");

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);

        TextField accountNumberField = new TextField();
        accountNumberField.setPromptText("GCash Account Number");

        grid.add(new Label("Account Number:"), 0, 0);
        grid.add(accountNumberField, 1, 0);

        gcashDialog.getDialogPane().setContent(grid);

        ButtonType payButton = new ButtonType("Pay", ButtonBar.ButtonData.OK_DONE);
        ButtonType cancelButton = new ButtonType("Cancel", ButtonBar.ButtonData.CANCEL_CLOSE);
        gcashDialog.getDialogPane().getButtonTypes().addAll(payButton, cancelButton);

        Platform.runLater(accountNumberField::requestFocus);

        gcashDialog.setResultConverter(dialogButton -> {
            if (dialogButton == payButton) {
                return accountNumberField.getText();
            }
            return null;
        });

        gcashDialog.showAndWait().ifPresent(accountNumber -> {
            if (paymentType.equals("water")) {
                processWaterPayment(accountNumber, "GCash");
            } else if (paymentType.equals("electricity")) {
                processElectricityPayment(accountNumber, "GCash");
            }
        });
    }

    private void processCardPayment(String paymentType) {
        Dialog<String[]> cardDialog = new Dialog<>();
        cardDialog.setTitle("Card Payment");
        cardDialog.setHeaderText("Enter Card Details");

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);

        TextField accountNumberField = new TextField();
        accountNumberField.setPromptText("Card Number");
        TextField cvvField = new TextField();
        cvvField.setPromptText("CVV");

        grid.add(new Label("Card Number:"), 0, 0);
        grid.add(accountNumberField, 1, 0);
        grid.add(new Label("CVV:"), 0, 1);
        grid.add(cvvField, 1, 1);

        cardDialog.getDialogPane().setContent(grid);

        ButtonType payButton = new ButtonType("Pay", ButtonBar.ButtonData.OK_DONE);
        ButtonType cancelButton = new ButtonType("Cancel", ButtonBar.ButtonData.CANCEL_CLOSE);
        cardDialog.getDialogPane().getButtonTypes().addAll(payButton, cancelButton);

        Platform.runLater(accountNumberField::requestFocus);

        cardDialog.setResultConverter(dialogButton -> {
            if (dialogButton == payButton) {
                return new String[]{accountNumberField.getText(), cvvField.getText()};
            }
            return null;
        });

        cardDialog.showAndWait().ifPresent(cardDetails -> {
            if (paymentType.equals("water")) {
                processWaterPayment(cardDetails[0], "Card");
            } else if (paymentType.equals("electricity")) {
                processElectricityPayment(cardDetails[0], "Card");
            }
        });
    }

    private void processWaterPayment(String accountNumber, String paymentMethod) {
        try {
            double paymentAmount = Double.parseDouble(waterpay.getText());
            double billAmount = Double.parseDouble(wateramount.getText());
            LocalDate selectedMonth = watermonth.getValue();

            // Check if the record exists for the selected user and month
            String checkQuery = "SELECT status, amount_paid, amount FROM water WHERE user_id = ? AND DATE_FORMAT(month, '%Y-%m') = ?";
            try (Connection connection = DBConnection.getConnection()) {
                PreparedStatement checkStmt = connection.prepareStatement(checkQuery);
                checkStmt.setInt(1, userId);
                checkStmt.setString(2, selectedMonth.getYear() + "-" + String.format("%02d", selectedMonth.getMonthValue()));

                ResultSet checkResultSet = checkStmt.executeQuery();

                if (!checkResultSet.next()) {
                    showErrorAlert("No Record Found", "No record found for the selected month and user.");
                    return;
                }

                double currentAmountPaid = checkResultSet.getDouble("amount_paid");
                double totalBillAmount = checkResultSet.getDouble("amount");
                double remainingBalance = totalBillAmount - currentAmountPaid;

                // If bill is already paid, check if there's a previous overpayment to apply
                if ("Paid".equalsIgnoreCase(checkResultSet.getString("status"))) {
                    showErrorAlert("Payment Error", "This month's bill has already been paid.");
                    return;
                }

                // Calculate if there will be an overpayment
                double newTotalPaid = currentAmountPaid + paymentAmount;
                double overpayment = 0;

                if (newTotalPaid > totalBillAmount) {
                    overpayment = newTotalPaid - totalBillAmount;
                    newTotalPaid = totalBillAmount; // Set the amount_paid to the full bill amount
                }

                // Determine payment status
                String paymentStatus;
                if (newTotalPaid >= totalBillAmount) {
                    paymentStatus = "Paid";
                } else {
                    paymentStatus = "Partial";
                }

                // Begin transaction
                connection.setAutoCommit(false);
                try {
                    // Update current month's payment
                    String updateQuery = "UPDATE water SET amount_paid = ?, status = ?, payment_method = ?, " +
                            "payment_date = ?, time_paid = NOW(), account_number = ? " +
                            "WHERE user_id = ? AND DATE_FORMAT(month, '%Y-%m') = ?";

                    PreparedStatement updateStmt = connection.prepareStatement(updateQuery);
                    updateStmt.setDouble(1, newTotalPaid);
                    updateStmt.setString(2, paymentStatus);
                    updateStmt.setString(3, paymentMethod);
                    updateStmt.setDate(4, java.sql.Date.valueOf(LocalDate.now()));
                    updateStmt.setString(5, accountNumber);
                    updateStmt.setInt(6, userId);
                    updateStmt.setString(7, selectedMonth.getYear() + "-" + String.format("%02d", selectedMonth.getMonthValue()));
                    updateStmt.executeUpdate();

                    // If there's an overpayment, apply it to the next unpaid bill
                    if (overpayment > 0) {
                        applyOverpaymentToNextBill(connection, "water", overpayment);
                    }

                    // Record in history
                    String historyQuery = "INSERT INTO history (user_id, id, info, date_time) VALUES (?, ?, ?, NOW())";
                    PreparedStatement historyStmt = connection.prepareStatement(historyQuery);

                    String paymentInfo = String.format("Water bill payment - Amount: %.2f, Month: %s, Method: %s, Status: %s" +
                                    (overpayment > 0 ? ", Overpayment: %.2f applied to next bill" : ""),
                            paymentAmount,
                            selectedMonth.format(DateTimeFormatter.ofPattern("MMM yyyy")),
                            paymentMethod,
                            paymentStatus,
                            overpayment);

                    historyStmt.setInt(1, userId);
                    historyStmt.setString(2, "water");
                    historyStmt.setString(3, paymentInfo);
                    historyStmt.executeUpdate();

                    connection.commit();
                    showSuccessAlert("Payment Successful",
                            String.format("Water bill payment processed successfully. Status: %s%s",
                                    paymentStatus,
                                    overpayment > 0 ? String.format("\nOverpayment of %.2f will be applied to next bill", overpayment) : ""));

                    loadWaterData(); // Refresh water data after payment

                } catch (SQLException e) {
                    connection.rollback();
                    throw e;
                } finally {
                    connection.setAutoCommit(true);
                }
            }
        } catch (NumberFormatException e) {
            showErrorAlert("Invalid Input", "Please enter a valid payment amount.");
        } catch (SQLException e) {
            showErrorAlert("Database Error", "Error processing payment: " + e.getMessage());
        }
    }

    private void processElectricityPayment(String accountNumber, String paymentMethod) {
        try {
            double paymentAmount = Double.parseDouble(electricitypay.getText());
            double billAmount = Double.parseDouble(electricityamount.getText());
            LocalDate selectedMonth = electricitymonth.getValue();

            // Check if the record exists for the selected user and month
            String checkQuery = "SELECT status, amount_paid, amount FROM electricity WHERE user_id = ? AND DATE_FORMAT(month, '%Y-%m') = ?";
            try (Connection connection = DBConnection.getConnection()) {
                PreparedStatement checkStmt = connection.prepareStatement(checkQuery);
                checkStmt.setInt(1, userId);
                checkStmt.setString(2, selectedMonth.getYear() + "-" + String.format("%02d", selectedMonth.getMonthValue()));

                ResultSet checkResultSet = checkStmt.executeQuery();

                if (!checkResultSet.next()) {
                    showErrorAlert("No Record Found", "No record found for the selected month and user.");
                    return;
                }

                double currentAmountPaid = checkResultSet.getDouble("amount_paid");
                double totalBillAmount = checkResultSet.getDouble("amount");
                double remainingBalance = totalBillAmount - currentAmountPaid;

                // If bill is already paid, check if there's a previous overpayment to apply
                if ("Paid".equalsIgnoreCase(checkResultSet.getString("status"))) {
                    showErrorAlert("Payment Error", "This month's bill has already been paid.");
                    return;
                }

                // Calculate if there will be an overpayment
                double newTotalPaid = currentAmountPaid + paymentAmount;
                double overpayment = 0;

                if (newTotalPaid > totalBillAmount) {
                    overpayment = newTotalPaid - totalBillAmount;
                    newTotalPaid = totalBillAmount; // Set the amount_paid to the full bill amount
                }

                // Determine payment status
                String paymentStatus;
                if (newTotalPaid >= totalBillAmount) {
                    paymentStatus = "Paid";
                } else {
                    paymentStatus = "Partial";
                }

                // Begin transaction
                connection.setAutoCommit(false);
                try {
                    // Update current month's payment
                    String updateQuery = "UPDATE electricity SET amount_paid = ?, status = ?, payment_method = ?, " +
                            "payment_date = ?, time_paid = NOW(), account_number = ? " +
                            "WHERE user_id = ? AND DATE_FORMAT(month, '%Y-%m') = ?";

                    PreparedStatement updateStmt = connection.prepareStatement(updateQuery);
                    updateStmt.setDouble(1, newTotalPaid);
                    updateStmt.setString(2, paymentStatus);
                    updateStmt.setString(3, paymentMethod);
                    updateStmt.setDate(4, java.sql.Date.valueOf(LocalDate.now()));
                    updateStmt.setString(5, accountNumber);
                    updateStmt.setInt(6, userId);
                    updateStmt.setString(7, selectedMonth.getYear() + "-" + String.format("%02d", selectedMonth.getMonthValue()));
                    updateStmt.executeUpdate();

                    // If there's an overpayment, apply it to the next unpaid bill
                    if (overpayment > 0) {
                        applyOverpaymentToNextBill(connection, "electricity", overpayment);
                    }

                    // Record in history
                    String historyQuery = "INSERT INTO history (user_id, id, info, date_time) VALUES (?, ?, ?, NOW())";
                    PreparedStatement historyStmt = connection.prepareStatement(historyQuery);

                    String paymentInfo = String.format("Electricity bill payment - Amount: %.2f, Month: %s, Method: %s, Status: %s" +
                                    (overpayment > 0 ? ", Overpayment: %.2f applied to next bill" : ""),
                            paymentAmount,
                            selectedMonth.format(DateTimeFormatter.ofPattern("MMM yyyy")),
                            paymentMethod,
                            paymentStatus,
                            overpayment);

                    historyStmt.setInt(1, userId);
                    historyStmt.setString(2, "electricity");
                    historyStmt.setString(3, paymentInfo);
                    historyStmt.executeUpdate();

                    connection.commit();
                    showSuccessAlert("Payment Successful",
                            String.format("Electricity bill payment processed successfully. Status: %s%s",
                                    paymentStatus,
                                    overpayment > 0 ? String.format("\nOverpayment of %.2f will be applied to next bill", overpayment) : ""));

                    loadElectricityData(); // Refresh electricity data after payment

                } catch (SQLException e) {
                    connection.rollback();
                    throw e;
                } finally {
                    connection.setAutoCommit(true);
                }
            }
        } catch (NumberFormatException e) {
            showErrorAlert("Invalid Input", "Please enter a valid payment amount.");
        } catch (SQLException e) {
            showErrorAlert("Database Error", "Error processing payment: " + e.getMessage());
        }
    }

    private void clearPaymentFields() {
        electricitypay.clear();
        electricitydate.setValue(null);
    }

    private boolean showConfirmationDialog(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);

        Optional<ButtonType> result = alert.showAndWait();
        return result.isPresent() && result.get() == ButtonType.OK;
    }

    private void applyOverpaymentToNextBill(Connection connection, String utility, double overpayment) throws SQLException {
        // Find the next unpaid bill
        String findNextBillQuery = String.format(
                "SELECT month, amount, amount_paid FROM %s WHERE user_id = ? " +
                        "AND status != 'Paid' AND DATE_FORMAT(month, '%%Y-%%m') > ? " +
                        "ORDER BY month ASC LIMIT 1", utility);

        PreparedStatement findStmt = connection.prepareStatement(findNextBillQuery);
        findStmt.setInt(1, userId);

        LocalDate currentMonth = utility.equals("water") ? watermonth.getValue() : electricitymonth.getValue();
        findStmt.setString(2, currentMonth.getYear() + "-" + String.format("%02d", currentMonth.getMonthValue()));

        ResultSet rs = findStmt.executeQuery();

        if (rs.next()) {
            double nextBillAmount = rs.getDouble("amount");
            double currentAmountPaid = rs.getDouble("amount_paid");
            double newAmountPaid = currentAmountPaid + overpayment;
            String status = newAmountPaid >= nextBillAmount ? "Paid" : "Partial";

            // Update the next bill with the overpayment
            String updateNextBillQuery = String.format(
                    "UPDATE %s SET amount_paid = ?, status = ? " +
                            "WHERE user_id = ? AND month = ?", utility);

            PreparedStatement updateStmt = connection.prepareStatement(updateNextBillQuery);
            updateStmt.setDouble(1, Math.min(newAmountPaid, nextBillAmount));
            updateStmt.setString(2, status);
            updateStmt.setInt(3, userId);
            updateStmt.setDate(4, rs.getDate("month"));
            updateStmt.executeUpdate();

            // If there's still remaining overpayment, recursively apply it to the next bill
            double remainingOverpayment = newAmountPaid - nextBillAmount;
            if (remainingOverpayment > 0) {
                applyOverpaymentToNextBill(connection, utility, remainingOverpayment);
            }
        }
    }

    // Add this method to format numbers with two decimal places
    private void setupPaymentTextField(TextField textField) {
        // Add a listener to format the text whenever it changes
        textField.textProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue == null || newValue.isEmpty()) {
                return;
            }

            // Remove any existing decimal places and non-digit characters
            String cleanValue = newValue.replaceAll("[^\\d]", "");

            try {
                // Convert to double and format with two decimal places
                double amount = Double.parseDouble(cleanValue) / 100.0;
                String formatted = String.format("%.2f", amount);

                // Only update if the formatted value is different
                if (!formatted.equals(newValue)) {
                    textField.setText(formatted);
                }
            } catch (NumberFormatException e) {
                // If parsing fails, just keep the clean value
                textField.setText(cleanValue);
            }
        });
    }

    // Add this debug method to help identify the issue
    private void debugPaymentFields() {
        System.out.println("Electric pay field value: '" + electricitypay.getText() + "'");
        System.out.println("Electric pay field is null?: " + (electricitypay == null));
        try {
            double value = Double.parseDouble(electricitypay.getText().trim());
            System.out.println("Parsed value: " + value);
        } catch (Exception e) {
            System.out.println("Parse error: " + e.getMessage());
        }
    }

    private void loadHistoryData() {
        String query = "SELECT id, info, date_time FROM history WHERE user_id = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, userId); // Use the logged-in user's ID
            try (ResultSet rs = stmt.executeQuery()) {
                ObservableList<HistoryEntry> historyEntries = FXCollections.observableArrayList();

                while (rs.next()) {
                    String id = rs.getString("id");
                    String info = rs.getString("info");

                    // Retrieve date_time as a Timestamp, then convert it to LocalDateTime
                    Timestamp timestamp = rs.getTimestamp("date_time");
                    LocalDateTime dateTime = timestamp.toLocalDateTime();

                    historyEntries.add(new HistoryEntry(id, info, dateTime));
                }

                // Bind the data to the TableView
                historyTableView.setItems(historyEntries);

                historyIdColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
                historyInfoColumn.setCellValueFactory(new PropertyValueFactory<>("info"));
                historyDateTimeColumn.setCellValueFactory(new PropertyValueFactory<>("dateTime"));
            }
        } catch (SQLException e) {
            showErrorAlert("Database Error", "Unable to load history data: " + e.getMessage());
        }
    }

    @FXML
    private void handleSubmit(ActionEvent event) {
        try {
            String selectedUserId = String.valueOf(userIdComboBox.getSelectionModel().getSelectedItem());
            if (selectedUserId == null || selectedUserId.trim().isEmpty()) {
                showAlert("Input Error", "Please select a valid User ID from the dropdown.");
                return;
            }
            int userId = Integer.parseInt(selectedUserId);

            if (kwphField.getText().trim().isEmpty() || !isInteger(kwphField.getText())) {
                showAlert("Input Error", "Please enter a valid KWPH value.");
                return;
            }
            int kwph = Integer.parseInt(kwphField.getText().trim());

            if (amountField.getText().trim().isEmpty() || !isDouble(amountField.getText())) {
                showAlert("Input Error", "Please enter a valid Amount.");
                return;
            }
            double amount = Double.parseDouble(amountField.getText().trim());

            LocalDate monthDate = monthDatepicker.getValue();
            if (monthDate == null) {
                showAlert("Input Error", "Please select a valid Month.");
                return;
            }

            if (landlordIdField.getText().trim().isEmpty() || !isInteger(landlordIdField.getText())) {
                showAlert("Input Error", "Please enter a valid Landlord ID.");
                return;
            }
            int landlordId = Integer.parseInt(landlordIdField.getText().trim());

            // Check if record already exists for the same user, month, and utility sector
            RadioButton selectedRadioButton = electricityRadio.isSelected() ? electricityRadio : waterRadio;
            if (selectedRadioButton == null) {
                showAlert("Input Error", "Please select a utility sector.");
                return;
            }
            String utilitySector = selectedRadioButton.equals(electricityRadio) ? "electricity" : "water";

            if (utilitySector.equals("electricity")) {
                if (isRecordExistsForElectricity(userId, monthDate)) {
                    showAlert("Record Exists", "A record already exists for electricity for this user in the selected month.");
                    return;
                }
            } else if (utilitySector.equals("water")) {
                if (isRecordExistsForWater(userId, monthDate)) {
                    showAlert("Record Exists", "A record already exists for water for this user in the selected month.");
                    return;
                }
            }

            // Insert into landlord_payments table
            int generatedReceiptId = insertIntoDatabase(userId, utilitySector, landlordId, kwph, amount, monthDate);

            // Additional table inserts for specific utility sector
            if (utilitySector.equals("electricity")) {
                insertIntoElectricityTable(userId, generatedReceiptId, kwph, amount, monthDate);
            } else {
                insertIntoWaterTable(userId, generatedReceiptId, kwph, amount, monthDate);
            }

            clearFormFields();

        } catch (NumberFormatException e) {
            showAlert("Input Error", "Please ensure all numeric fields have valid numbers.");
        } catch (Exception e) {
            showAlert("Unexpected Error", "An unexpected error occurred: " + e.getMessage());
        }
    }

    private boolean isRecordExistsForElectricity(int userId, LocalDate monthDate) {
        String checkQuery = "SELECT 1 FROM electricity WHERE user_id = ? AND DATE_FORMAT(month, '%Y-%m') = ?";
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement stmt = connection.prepareStatement(checkQuery)) {

            stmt.setInt(1, userId);
            stmt.setString(2, monthDate.getYear() + "-" + String.format("%02d", monthDate.getMonthValue()));

            ResultSet resultSet = stmt.executeQuery();
            return resultSet.next();  // If a record is found, return true
        } catch (SQLException e) {
            showAlert("Database Error", "Error checking for existing electricity record: " + e.getMessage());
        }
        return false;
    }

    private boolean isRecordExistsForWater(int userId, LocalDate monthDate) {
        String checkQuery = "SELECT 1 FROM water WHERE user_id = ? AND DATE_FORMAT(month, '%Y-%m') = ?";
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement stmt = connection.prepareStatement(checkQuery)) {

            stmt.setInt(1, userId);
            stmt.setString(2, monthDate.getYear() + "-" + String.format("%02d", monthDate.getMonthValue()));

            ResultSet resultSet = stmt.executeQuery();
            return resultSet.next();  // If a record is found, return true
        } catch (SQLException e) {
            showAlert("Database Error", "Error checking for existing water record: " + e.getMessage());
        }
        return false;
    }



    // Method to insert data into the landlord_payments database table
    private int insertIntoDatabase(int userId, String utilitySector, int landlordId, int kwph, double amount, LocalDate date) {
        String sql = "INSERT INTO landlord_payments (user_id, utility_sector, landlord_id, utility_kwph, utility_amount, date_recorded) " +
                "VALUES (?, ?, ?, ?, ?, ?)";
        int generatedReceiptId = -1;

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            stmt.setInt(1, userId);
            stmt.setString(2, utilitySector);
            stmt.setInt(3, landlordId);
            stmt.setInt(4, kwph);
            stmt.setDouble(5, amount);
            stmt.setObject(6, date);

            int affectedRows = stmt.executeUpdate();
            if (affectedRows > 0) {
                // Retrieve the auto-generated receipt_id
                try (ResultSet rs = stmt.getGeneratedKeys()) {
                    if (rs.next()) {
                        generatedReceiptId = rs.getInt(1);
                    }
                }
            } else {
                showAlert("Database Error", "Failed to insert record into landlord_payments table.");
            }
        } catch (SQLException e) {
            showAlert("Database Error", "Failed to insert record: " + e.getMessage());
        }

        return generatedReceiptId;
    }

    private void insertIntoWaterTable(int userId, int kwph, double amount, double v, LocalDate month) {
        String sql = "INSERT INTO water (user_id, kwph, amount, month) VALUES (?, ?, ?, ?)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, userId);
            stmt.setInt(2, kwph);
            stmt.setDouble(3, amount);
            stmt.setObject(4, month);

            int rowsInserted = stmt.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("Water record inserted successfully.");
            }
        } catch (SQLException e) {
            showAlert("Database Error", "Failed to insert into water table: " + e.getMessage());
        }
    }



    private void insertIntoElectricityTable(int userId, int kwph, double amount, double v, LocalDate month) {
        String sql = "INSERT INTO electricity (user_id, kwph, amount, month) VALUES (?, ?, ?, ?)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, userId);
            stmt.setInt(2, kwph);
            stmt.setDouble(3, amount);
            stmt.setObject(4, month);

            int rowsInserted = stmt.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("Electricity record inserted successfully.");
            }
        } catch (SQLException e) {
            showAlert("Database Error", "Failed to insert into electricity table: " + e.getMessage());
        }
    }


    private void clearFormFields() {
        // Clear the form fields
        kwphField.clear();
        amountField.clear();
        monthDatepicker.setValue(null);
        userIdComboBox.getSelectionModel().clearSelection();
        electricityRadio.setSelected(false);
        waterRadio.setSelected(false);
    }

    private void populateUserIdDropdown() {
        List<Integer> userIds = new ArrayList<>();

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement("SELECT id FROM user_account")) {
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    userIds.add(rs.getInt("id"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        // Populate ComboBox with Integer objects
        userIdComboBox.setItems(FXCollections.observableArrayList(userIds));
    }
    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR); // Use AlertType.ERROR for error messages
        alert.setTitle(title); // Set the title of the alert
        alert.setHeaderText(null); // Optional: Remove the header
        alert.setContentText(message); // Set the main content message
        alert.showAndWait(); // Display the alert and wait for user to close it
    }

    private boolean isInteger(String input) {
        try {
            Integer.parseInt(input); // Try to parse the input as an integer
            return true; // If successful, return true
        } catch (NumberFormatException e) {
            return false; // If parsing fails, return false
        }
    }

    private boolean isDouble(String input) {
        try {
            Double.parseDouble(input); // Try to parse the input as a double
            return true; // If successful, return true
        } catch (NumberFormatException e) {
            return false; // If parsing fails, return false
        }
    }
}

